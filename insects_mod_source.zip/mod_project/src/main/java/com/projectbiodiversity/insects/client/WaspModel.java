package com.projectbiodiversity.insects.client;

import com.projectbiodiversity.insects.InsectsMod;
import com.projectbiodiversity.insects.entity.WaspEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class WaspModel extends GeoModel<WaspEntity> {

    @Override
    public ResourceLocation getModelResource(WaspEntity object) {
        return new ResourceLocation(InsectsMod.MOD_ID, "geo/wasp.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(WaspEntity object) {
        return new ResourceLocation(InsectsMod.MOD_ID, "textures/entity/wasp.png");
    }

    @Override
    public ResourceLocation getAnimationResource(WaspEntity animatable) {
        return new ResourceLocation(InsectsMod.MOD_ID, "animations/waspfly.animation.json");
    }
}
