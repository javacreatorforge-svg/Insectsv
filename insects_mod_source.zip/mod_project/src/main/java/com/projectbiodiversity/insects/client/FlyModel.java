package com.projectbiodiversity.insects.client;

import com.projectbiodiversity.insects.InsectsMod;
import com.projectbiodiversity.insects.entity.FlyEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class FlyModel extends GeoModel<FlyEntity> {

    @Override
    public ResourceLocation getModelResource(FlyEntity object) {
        return new ResourceLocation(InsectsMod.MOD_ID, "geo/fly.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(FlyEntity object) {
        if (object.isEasterEgg()) {
            return new ResourceLocation(InsectsMod.MOD_ID, "textures/entity/fly_easter_egg.png");
        }
        return new ResourceLocation(InsectsMod.MOD_ID, "textures/entity/fly.png");
    }

    @Override
    public ResourceLocation getAnimationResource(FlyEntity animatable) {
        return new ResourceLocation(InsectsMod.MOD_ID, "animations/flyflying.animation.json");
    }
}
