package com.projectbiodiversity.insects.registry;

import com.projectbiodiversity.insects.InsectsMod;
import com.projectbiodiversity.insects.item.InsectsDictionaryItem;
import net.minecraft.world.item.*;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, InsectsMod.MOD_ID);

    public static final RegistryObject<Item> FLY_SPAWN_EGG = ITEMS.register("fly_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.FLY, 0x6B6B4A, 0xC8C87A,
                    new Item.Properties()));

    public static final RegistryObject<Item> WASP_SPAWN_EGG = ITEMS.register("wasp_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.WASP, 0xFFCC00, 0x1A1A1A,
                    new Item.Properties()));

    public static final RegistryObject<Item> INSECTS_DICTIONARY = ITEMS.register("insects_dictionary",
            () -> new InsectsDictionaryItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> WASP_NEST_BLOCK_ITEM = ITEMS.register("wasp_nest",
            () -> new BlockItem(ModBlocks.WASP_NEST.get(), new Item.Properties()));
}
