package com.projectbiodiversity.insects;

import com.projectbiodiversity.insects.registry.ModEntities;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.world.BiomeLoadingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = InsectsMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ModEvents {

    @SubscribeEvent
    public static void onBiomeLoad(BiomeLoadingEvent event) {
        String biomeName = event.getName() != null ? event.getName().toString() : "";

        // Fly: spawns in plains, overworld broadly
        if (biomeName.contains("plains") || biomeName.contains("meadow") ||
                biomeName.contains("sunflower") || biomeName.contains("grass")) {
            event.getSpawns().addSpawn(MobCategory.AMBIENT,
                    new MobSpawnSettings.SpawnerData(ModEntities.FLY.get(), 8, 1, 3));
        }

        // Wasp: spawns in plains, birch forest, taiga, overworld broadly
        if (biomeName.contains("plains") || biomeName.contains("birch") ||
                biomeName.contains("taiga") || biomeName.contains("meadow") ||
                biomeName.contains("forest") || biomeName.contains("grove")) {
            event.getSpawns().addSpawn(MobCategory.MONSTER,
                    new MobSpawnSettings.SpawnerData(ModEntities.WASP.get(), 4, 1, 2));
        }
    }
}
