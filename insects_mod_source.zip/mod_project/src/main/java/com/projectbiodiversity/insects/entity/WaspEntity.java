package com.projectbiodiversity.insects.entity;

import com.projectbiodiversity.insects.block.WaspNestBlock;
import com.projectbiodiversity.insects.registry.ModBlocks;
import com.projectbiodiversity.insects.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.feature.foliageplacers.FancyFoliagePlacer;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import javax.annotation.Nullable;
import java.util.Optional;

public class WaspEntity extends Monster implements GeoEntity {

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    // Nest position — set on spawn
    @Nullable
    private BlockPos nestPos = null;

    // How long wasp stays inside nest
    private int nestTimer = 0;
    private boolean insideNest = false;

    // Flower visiting
    @Nullable
    private BlockPos flowerPos = null;
    private int flowerTimer = 0;
    private int flowerSearchCooldown = 0;

    // Sound
    private int soundCooldown = 0;

    // Sting attack tracking (for animation)
    private boolean isStinging = false;
    private int stingTimer = 0;

    public WaspEntity(EntityType<? extends WaspEntity> type, Level level) {
        super(type, level);
        this.setNoGravity(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 10.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.FLYING_SPEED, 0.7)
                .add(Attributes.ATTACK_DAMAGE, 4.0)
                .add(Attributes.FOLLOW_RANGE, 24.0)
                .add(Attributes.ARMOR, 2.0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new WaspAttackGoal(this));
        this.goalSelector.addGoal(3, new WaspVisitFlowerGoal(this));
        this.goalSelector.addGoal(4, new WaspReturnToNestGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomFlyingGoal(this, 1.0));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0f));

        this.targetSelector.addGoal(1, new WaspNestDefenseTargetGoal(this));
        this.targetSelector.addGoal(2, new HurtByTargetGoal(this));
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && target instanceof LivingEntity living) {
            living.addEffect(new MobEffectInstance(MobEffects.POISON, 120, 0)); // Poison 6s
            isStinging = true;
            stingTimer = 7; // ~0.35s at 20 ticks/s
        }
        return hit;
    }

    @Override
    public void tick() {
        super.tick();

        if (!this.level().isClientSide()) {
            // Play flying sound near players
            Player nearestPlayer = this.level().getNearestPlayer(this, 10.0);
            if (nearestPlayer != null) {
                soundCooldown--;
                if (soundCooldown <= 0) {
                    this.playSound(ModSounds.WASP_FLYING.get(), 0.5f, 1.0f);
                    soundCooldown = 60;
                }
            } else {
                soundCooldown = 0;
            }

            // Sting animation timer
            if (stingTimer > 0) {
                stingTimer--;
                if (stingTimer <= 0) isStinging = false;
            }

            // Nest respawn timer when inside nest
            if (insideNest) {
                nestTimer--;
                if (nestTimer <= 0) {
                    insideNest = false;
                    if (nestPos != null) {
                        this.teleportTo(nestPos.getX() + 0.5, nestPos.getY() + 1.2, nestPos.getZ() + 0.5);
                        this.setInvisible(false);
                    }
                }
            }
        }
    }

    public void setNestPos(@Nullable BlockPos pos) {
        this.nestPos = pos;
    }

    @Nullable
    public BlockPos getNestPos() {
        return nestPos;
    }

    public boolean isInsideNest() {
        return insideNest;
    }

    public void enterNest() {
        this.insideNest = true;
        this.nestTimer = 600; // 30 seconds
        this.setInvisible(true);
        this.setTarget(null);
    }

    public boolean isStinging() {
        return isStinging;
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("NestX")) {
            nestPos = new BlockPos(tag.getInt("NestX"), tag.getInt("NestY"), tag.getInt("NestZ"));
        }
        insideNest = tag.getBoolean("InsideNest");
        nestTimer = tag.getInt("NestTimer");
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (nestPos != null) {
            tag.putInt("NestX", nestPos.getX());
            tag.putInt("NestY", nestPos.getY());
            tag.putInt("NestZ", nestPos.getZ());
        }
        tag.putBoolean("InsideNest", insideNest);
        tag.putInt("NestTimer", nestTimer);
    }

    // GeckoLib animations
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 2, this::predicate));
    }

    private PlayState predicate(AnimationState<WaspEntity> state) {
        if (isStinging) {
            state.getController().setAnimation(
                    RawAnimation.begin().then("animation.project_biodiversity.wasp.sting_fly", Animation.LoopType.PLAY_ONCE));
            return PlayState.CONTINUE;
        }

        if (this.getDeltaMovement().horizontalDistanceSqr() > 0.001 || this.getDeltaMovement().y != 0) {
            if (!this.onGround()) {
                state.getController().setAnimation(
                        RawAnimation.begin().then("animation.project_biodiversity.wasp.fly", Animation.LoopType.LOOP));
            } else {
                state.getController().setAnimation(
                        RawAnimation.begin().then("animation.project_biodiversity.wasp.walk", Animation.LoopType.LOOP));
            }
        } else {
            state.getController().setAnimation(
                    RawAnimation.begin().then("animation.project_biodiversity:wasp.idle", Animation.LoopType.LOOP));
        }
        return PlayState.CONTINUE;
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.BEE_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.BEE_DEATH;
    }

    @Override
    public MobType getMobType() {
        return MobType.ARTHROPOD;
    }

    // ---- Inner Goal: Attack entities near nest ----
    static class WaspNestDefenseTargetGoal extends NearestAttackableTargetGoal<LivingEntity> {
        private final WaspEntity wasp;

        WaspNestDefenseTargetGoal(WaspEntity wasp) {
            super(wasp, LivingEntity.class, true, false);
            this.wasp = wasp;
        }

        @Override
        public boolean canUse() {
            if (wasp.isInsideNest() || wasp.getNestPos() == null) return false;
            BlockPos nest = wasp.getNestPos();
            // Only target entities within 8 blocks of nest
            AABB nestArea = new AABB(nest).inflate(8.0);
            LivingEntity target = wasp.level().getNearestEntity(
                    LivingEntity.class, null, wasp, wasp.getX(), wasp.getY(), wasp.getZ(), nestArea);
            if (target == null || target == wasp) return false;
            this.targetMob = target;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            if (wasp.getNestPos() == null || this.targetMob == null) return false;
            // Stop if target moved far from nest
            BlockPos nest = wasp.getNestPos();
            return targetMob.distanceToSqr(nest.getX(), nest.getY(), nest.getZ()) < 16 * 16;
        }
    }

    // ---- Inner Goal: Melee attack ----
    static class WaspAttackGoal extends MeleeAttackGoal {
        WaspAttackGoal(WaspEntity wasp) {
            super(wasp, 1.0, false);
        }
    }

    // ---- Inner Goal: Visit flowers like bees ----
    static class WaspVisitFlowerGoal extends Goal {
        private final WaspEntity wasp;
        private int timer = 0;

        WaspVisitFlowerGoal(WaspEntity wasp) {
            this.wasp = wasp;
        }

        @Override
        public boolean canUse() {
            if (wasp.getTarget() != null || wasp.isInsideNest()) return false;
            wasp.flowerSearchCooldown--;
            if (wasp.flowerSearchCooldown > 0) return false;
            wasp.flowerSearchCooldown = 200;
            // Find a flower nearby
            BlockPos pos = wasp.blockPosition();
            for (int dx = -8; dx <= 8; dx++) {
                for (int dy = -3; dy <= 3; dy++) {
                    for (int dz = -8; dz <= 8; dz++) {
                        BlockPos check = pos.offset(dx, dy, dz);
                        if (wasp.level().getBlockState(check).is(net.minecraft.tags.BlockTags.FLOWERS)) {
                            wasp.flowerPos = check;
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        @Override
        public boolean canContinueToUse() {
            return wasp.flowerPos != null && timer < 80 && wasp.getTarget() == null && !wasp.isInsideNest();
        }

        @Override
        public void start() {
            timer = 0;
        }

        @Override
        public void tick() {
            if (wasp.flowerPos != null) {
                wasp.getNavigation().moveTo(
                        wasp.flowerPos.getX() + 0.5,
                        wasp.flowerPos.getY() + 0.8,
                        wasp.flowerPos.getZ() + 0.5,
                        1.0);
                timer++;
            }
        }

        @Override
        public void stop() {
            wasp.flowerPos = null;
            // After visiting flower, head back to nest
        }
    }

    // ---- Inner Goal: Return to nest and disappear for 30s ----
    static class WaspReturnToNestGoal extends Goal {
        private final WaspEntity wasp;
        private int delayTimer = 300; // wait before returning

        WaspReturnToNestGoal(WaspEntity wasp) {
            this.wasp = wasp;
        }

        @Override
        public boolean canUse() {
            if (wasp.isInsideNest() || wasp.getNestPos() == null || wasp.getTarget() != null) return false;
            delayTimer--;
            if (delayTimer > 0) return false;
            delayTimer = 400;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            if (wasp.getNestPos() == null) return false;
            return wasp.distanceToSqr(Vec3.atCenterOf(wasp.getNestPos())) > 2.0;
        }

        @Override
        public void tick() {
            BlockPos nest = wasp.getNestPos();
            if (nest != null) {
                wasp.getNavigation().moveTo(nest.getX() + 0.5, nest.getY() + 0.5, nest.getZ() + 0.5, 1.1);
                // If close enough, enter nest
                if (wasp.distanceToSqr(Vec3.atCenterOf(nest)) < 2.5) {
                    wasp.enterNest();
                }
            }
        }
    }
}
