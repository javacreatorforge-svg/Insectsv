package com.projectbiodiversity.insects.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.projectbiodiversity.insects.entity.WaspEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class WaspRenderer extends GeoEntityRenderer<WaspEntity> {

    public WaspRenderer(EntityRendererProvider.Context context) {
        super(context, new WaspModel());
    }

    @Override
    public void render(WaspEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource bufferSource, int packedLight) {
        poseStack.pushPose();
        poseStack.scale(0.7f, 0.7f, 0.7f);
        super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
        poseStack.popPose();
    }
}
