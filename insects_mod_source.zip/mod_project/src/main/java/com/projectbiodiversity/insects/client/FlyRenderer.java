package com.projectbiodiversity.insects.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.projectbiodiversity.insects.entity.FlyEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class FlyRenderer extends GeoEntityRenderer<FlyEntity> {

    public FlyRenderer(EntityRendererProvider.Context context) {
        super(context, new FlyModel());
    }

    @Override
    public void render(FlyEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource bufferSource, int packedLight) {
        if (entity.isEasterEgg()) {
            // Easter egg: render as billboard sprite — hide the 3D model,
            // the texture swap in FlyModel handles showing the easter egg image
            poseStack.pushPose();
            poseStack.scale(1.5f, 1.5f, 1.5f);
            super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
            poseStack.popPose();
        } else {
            poseStack.pushPose();
            poseStack.scale(0.5f, 0.5f, 0.5f);
            super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
            poseStack.popPose();
        }
    }
}
