package com.projectbiodiversity.insects.entity;

import com.projectbiodiversity.insects.InsectsMod;
import com.projectbiodiversity.insects.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CakeBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import javax.annotation.Nullable;

public class FlyEntity extends PathfinderMob implements GeoEntity {

    private static final EntityDataAccessor<Boolean> IS_EASTER_EGG =
            SynchedEntityData.defineId(FlyEntity.class, EntityDataSerializers.BOOLEAN);

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    // Sound cooldown: play nearby sound every ~3s
    private int soundCooldown = 0;

    // Cake target tracking
    @Nullable
    private BlockPos targetCakePos = null;
    private int cakeSearchCooldown = 0;

    // Easter egg: follow and stare at player
    @Nullable
    private Player stareTarget = null;

    public FlyEntity(EntityType<? extends FlyEntity> type, Level level) {
        super(type, level);
        this.setNoGravity(true); // flies
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 6.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.FLYING_SPEED, 0.6)
                .add(Attributes.FOLLOW_RANGE, 16.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(IS_EASTER_EGG, false);
    }

    public boolean isEasterEgg() {
        return this.entityData.get(IS_EASTER_EGG);
    }

    public void setEasterEgg(boolean value) {
        this.entityData.set(IS_EASTER_EGG, value);
        if (value) {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(500.0);
            this.setHealth(500.0f);
        }
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (IS_EASTER_EGG.equals(key) && isEasterEgg()) {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(500.0);
        }
    }

    @Override
    protected void registerGoals() {
        // Easter egg: just stare at nearest player, no other goals
        // Normal goals:
        this.goalSelector.addGoal(1, new AvoidEntityGoal<>(this, Player.class, 6.0f, 1.2, 1.4));
        this.goalSelector.addGoal(2, new FlyTowardsCakeGoal(this));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomFlyingGoal(this, 1.0));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 6.0f));
    }

    @Override
    public void tick() {
        super.tick();

        if (!this.level().isClientSide()) {
            // Play nearby sound when player is close
            Player nearestPlayer = this.level().getNearestPlayer(this, 8.0);
            if (nearestPlayer != null) {
                soundCooldown--;
                if (soundCooldown <= 0) {
                    this.playSound(ModSounds.FLY_FLYING.get(), 0.4f, 1.0f);
                    soundCooldown = 60; // ~3 seconds
                }
            } else {
                soundCooldown = 0;
            }

            // Easter egg: track nearest player for staring
            if (isEasterEgg()) {
                stareTarget = this.level().getNearestPlayer(this, 32.0);
                if (stareTarget != null) {
                    // Slowly drift toward player
                    Vec3 diff = stareTarget.position().subtract(this.position());
                    if (diff.length() > 2.0) {
                        Vec3 move = diff.normalize().scale(0.15);
                        this.setDeltaMovement(move);
                    } else {
                        this.setDeltaMovement(Vec3.ZERO);
                    }
                    this.getLookControl().setLookAt(stareTarget, 30.0f, 30.0f);
                }
            }
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("IsEasterEgg")) {
            setEasterEgg(tag.getBoolean("IsEasterEgg"));
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("IsEasterEgg", isEasterEgg());
    }

    // Called when named with a Name Tag
    @Override
    public void setCustomName(@Nullable net.minecraft.network.chat.Component name) {
        super.setCustomName(name);
        if (name != null && name.getString().equalsIgnoreCase("walk")) {
            setEasterEgg(true);
        }
    }

    // GeckoLib animation
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 2, this::predicate));
    }

    private PlayState predicate(AnimationState<FlyEntity> state) {
        if (isEasterEgg()) {
            // Easter egg: just stays still and stares — use idle
            state.getController().setAnimation(
                    RawAnimation.begin().then("animation.project_biodiversity:fly.idle", Animation.LoopType.LOOP));
            return PlayState.CONTINUE;
        }

        if (this.getDeltaMovement().horizontalDistanceSqr() > 0.001 || this.getDeltaMovement().y != 0) {
            // Moving — check if flying or walking
            if (!this.onGround()) {
                state.getController().setAnimation(
                        RawAnimation.begin().then("animation.project_biodiversity.fly.fly", Animation.LoopType.LOOP));
            } else {
                state.getController().setAnimation(
                        RawAnimation.begin().then("animation.project_biodiversity.fly.walk", Animation.LoopType.LOOP));
            }
        } else {
            state.getController().setAnimation(
                    RawAnimation.begin().then("animation.project_biodiversity:fly.idle", Animation.LoopType.LOOP));
        }
        return PlayState.CONTINUE;
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.BEE_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.BEE_DEATH;
    }

    @Override
    public MobType getMobType() {
        return MobType.ARTHROPOD;
    }

    // ---- Inner goal: fly to nearby cake and sit on it ----
    static class FlyTowardsCakeGoal extends Goal {
        private final FlyEntity fly;
        private int checkTimer = 0;

        FlyTowardsCakeGoal(FlyEntity fly) {
            this.fly = fly;
        }

        @Override
        public boolean canUse() {
            if (fly.isEasterEgg()) return false;
            checkTimer--;
            if (checkTimer > 0) return false;
            checkTimer = 40;
            // Search for a cake within 12 blocks
            BlockPos pos = fly.blockPosition();
            for (int dx = -6; dx <= 6; dx++) {
                for (int dy = -3; dy <= 3; dy++) {
                    for (int dz = -6; dz <= 6; dz++) {
                        BlockPos check = pos.offset(dx, dy, dz);
                        BlockState state = fly.level().getBlockState(check);
                        if (state.is(Blocks.CAKE)) {
                            fly.targetCakePos = check;
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        @Override
        public boolean canContinueToUse() {
            if (fly.isEasterEgg() || fly.targetCakePos == null) return false;
            BlockState state = fly.level().getBlockState(fly.targetCakePos);
            return state.is(Blocks.CAKE);
        }

        @Override
        public void tick() {
            if (fly.targetCakePos != null) {
                fly.getNavigation().moveTo(
                        fly.targetCakePos.getX() + 0.5,
                        fly.targetCakePos.getY() + 0.5,
                        fly.targetCakePos.getZ() + 0.5,
                        1.0
                );
            }
        }

        @Override
        public void stop() {
            fly.targetCakePos = null;
        }
    }
}
