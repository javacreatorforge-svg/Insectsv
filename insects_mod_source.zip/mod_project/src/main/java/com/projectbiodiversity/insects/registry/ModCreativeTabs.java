package com.projectbiodiversity.insects.registry;

import com.projectbiodiversity.insects.InsectsMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, InsectsMod.MOD_ID);

    public static final RegistryObject<CreativeModeTab> INSECTS_TAB = TABS.register("insects",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.insects"))
                    .icon(() -> new ItemStack(ModItems.INSECTS_DICTIONARY.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.FLY_SPAWN_EGG.get());
                        output.accept(ModItems.WASP_SPAWN_EGG.get());
                        output.accept(ModItems.WASP_NEST_BLOCK_ITEM.get());
                        output.accept(ModItems.INSECTS_DICTIONARY.get());
                    })
                    .build());
}
