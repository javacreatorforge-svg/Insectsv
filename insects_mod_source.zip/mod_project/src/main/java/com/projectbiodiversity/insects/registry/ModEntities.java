package com.projectbiodiversity.insects.registry;

import com.projectbiodiversity.insects.InsectsMod;
import com.projectbiodiversity.insects.entity.FlyEntity;
import com.projectbiodiversity.insects.entity.WaspEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, InsectsMod.MOD_ID);

    public static final RegistryObject<EntityType<FlyEntity>> FLY = ENTITIES.register("fly",
            () -> EntityType.Builder.<FlyEntity>of(FlyEntity::new, MobCategory.AMBIENT)
                    .sized(0.4f, 0.3f)
                    .build(InsectsMod.MOD_ID + ":fly"));

    public static final RegistryObject<EntityType<WaspEntity>> WASP = ENTITIES.register("wasp",
            () -> EntityType.Builder.<WaspEntity>of(WaspEntity::new, MobCategory.MONSTER)
                    .sized(0.6f, 0.5f)
                    .build(InsectsMod.MOD_ID + ":wasp"));

    public static void registerEntityAttributes(EntityAttributeCreationEvent event) {
        event.put(FLY.get(), FlyEntity.createAttributes().build());
        event.put(WASP.get(), WaspEntity.createAttributes().build());
    }
}
