package com.projectbiodiversity.insects.registry;

import com.projectbiodiversity.insects.InsectsMod;
import com.projectbiodiversity.insects.block.WaspNestBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, InsectsMod.MOD_ID);

    public static final RegistryObject<Block> WASP_NEST = BLOCKS.register("wasp_nest",
            () -> new WaspNestBlock(BlockBehaviour.Properties.of()
                    .strength(0.3f)
                    .sound(SoundType.WOOL)
                    .noOcclusion()));
}
