package com.projectbiodiversity.insects.registry;

import com.projectbiodiversity.insects.InsectsMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, InsectsMod.MOD_ID);

    public static final RegistryObject<SoundEvent> FLY_FLYING = SOUNDS.register("fly_flying",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(InsectsMod.MOD_ID, "fly_flying")));

    public static final RegistryObject<SoundEvent> WASP_FLYING = SOUNDS.register("wasp_flying",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(InsectsMod.MOD_ID, "wasp_flying")));
}
